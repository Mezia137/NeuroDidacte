import numpy as np
import random as rd
from alphazero import NeuralNetworkWrapper
import os
from alphazero import CFG
from alphazero import Train

class TicTacToe:
    def __init__(self, P=1):
        '''Initialize TicTacToe game.'''
        self.board = np.zeros((3, 3), dtype=int)  # Create an empty 3x3 game board filled with zeros.
        self.row = 3  # Number of rows in the game board.
        self.column = 3  # Number of columns in the game board.
        self.action_size = 9  # Total number of possible actions in the game.
        self.current_player = P  # Current player (1 for player 1, -1 for player 2).

    def clone(self):
        '''Clone the current game state.'''
        clone_game = TicTacToe()  # Create a new instance of the TicTacToe game.
        clone_game.board = np.copy(self.board)  # Copy the current game board to the new instance.
        clone_game.current_player = self.current_player  # Copy the current player to the new instance.
        return clone_game

    def restart_game(self, P=1):
        '''Restart the game.'''
        self.board = np.zeros((3, 3), dtype=int)  # Reset the game board to an empty state.
        self.current_player = P  # Reset the current player.

    def print_board(self):
        '''Print the current game board.'''
        for row in self.board:
            print(" ".join(["X" if case == 1 else "O" if case == -1 else "-" for case in row]))  # Print each row of the game board.

    def get_possible_move(self):
        '''Get all possible moves.'''
        return [(i, j) for i in range(3) for j in range(3) if self.board[i, j] == 0]  # Find all empty cells in the game board.

    def get_valid_move(self):
        '''Get valid moves.'''
        valid_moves = []
        possible_actions = self.get_possible_move()  # Get all possible moves.
        for x in range(self.row):
            for y in range(self.column):
                if ((x,y) in possible_actions):
                    valid_moves.append((1, x, y))  # If the move is valid, append (1, row, column).
                else:
                    valid_moves.append((0, None, None))  # If the move is invalid, append (0, None, None).
        return np.array(valid_moves)

    def is_valid_move(self, row, col):
        '''Check if the move is valid.'''
        return 0 <= row < 3 and 0 <= col < 3 and self.board[row, col] == 0  # Return True if the cell is empty and within the bounds of the game board.

    def make_move(self, row, col):
        '''Make a move.'''
        if self.is_valid_move(row, col):
            self.board[row, col] = self.current_player  # Set the cell to the current player's symbol.
            self.current_player *= -1  # Switch to the next player.
            return True  # Return True to indicate a successful move.
        else:
            return False  # Return False to indicate an invalid move.

    def check_winner(self, player=1):
        '''Check if there's a winner.'''
        for i in range(3):
            if np.all(self.board[i, :] == player) or np.all(self.board[:, i] == player):
                return True, 1  # Return True and 1 if there's a row or column with the same symbol.
            elif np.all(self.board[i, :] == -player) or np.all(self.board[:, i] == -player):
                return True, -1  # Return True and -1 if there's a row or column with the opposite symbol.

        if np.all(np.diag(self.board) == player) or np.all(np.diag(np.fliplr(self.board)) == player):
            return True, 1  # Return True and 1 if there's a diagonal with the same symbol.
        elif np.all(np.diag(self.board) == -player) or np.all(np.diag(np.fliplr(self.board)) == -player):
            return True, -1  # Return True and -1 if there's a diagonal with the opposite symbol.

        if np.all(self.board != 0):
            return True, 0  # Return True and 0 if the game board is full with no winner.

        return False, 0  # Return False and 0 if there's no winner and the game is not finished.

    def play(self, player1, player2):
        '''Play the game.'''
        while True:
            if self.current_player == 1:
                player1.make_move(self)  # Player 1 makes a move.
            else:
                player2.make_move(self)  # Player 2 makes a move.
            w, winner = self.check_winner()  # Check if there's a winner after each move.
            if w is True:
                return winner  # Return the winner of the game.

class HumanPlayer:
    def make_move(self, game):
        '''Human player makes a move.'''
        while True:
            try:
                row = int(input("Enter row (0, 1, or 2): "))  # Prompt the user to enter a row.
                col = int(input("Enter column (0, 1, or 2): "))  # Prompt the user to enter a column.
                if game.is_valid_move(row, col):
                    game.make_move(row, col)  # Make the move if it's valid.
                    break
                else:
                    print("Invalid move. Try again.")  # Print an error message if the move is invalid.
            except ValueError:
                print("Invalid input. Enter numbers only.")  # Print an error message if the input is not a number.

class RandomPlayer:
    def make_move(self, game):
        '''Random player makes a move.'''
        while True:
            random_move = rd.choice(game.get_possible_move())  # Choose a random move from the list of possible moves.
            if game.is_valid_move(random_move[0], random_move[1]):
                game.make_move(random_move[0], random_move[1])  # Make the move if it's valid.
                break

class NNPlayer:
    def __init__(self, game, model="./models/"):
        '''Initialize NNPlayer.'''
        self.NN = NeuralNetworkWrapper(game, model=model)

    def make_move(self, game):
        '''NNPlayer makes a move.'''
        state = game.board
        move_probs = self.NN.play(game)  # Get the move probabilities from the neural network.
        best_move_index = np.argmax(move_probs)
        best_move = (best_move_index // 3, best_move_index % 3)  # Convert the index to row and column.
        game.make_move(best_move[0], best_move[1])  # Make the best move.

def train():
    '''Train the model.'''
    game = TicTacToe()
    model = "./models2/"
    net = NeuralNetworkWrapper(game, model=model)
    if CFG.load_model:
        file_path = model
        if os.path.exists(file_path):
            net.load_model("best_model")
        else:
            print("Trained model doesn't exist. Starting from scratch.")
    else:
        print("Trained model not loaded. Starting from scratch.")

    trainer = Train(game, net)
    trainer.start()

def main():
    '''Main function'''
    game = TicTacToe(P=1)
    player2 = HumanPlayer()
    player1 = NNPlayer(game, model ="./models2/")
    v1 = 0
    v2 = 0
    for i in range(10):
        winner = game.play(player1, player2)
        if winner == 1:
            v1 += 1
        elif winner == -1:
            v2 += 1
        game.restart_game()
        print(i+1) 
    print (v1, v2)

if __name__ == "__main__":
    main()
    


    


